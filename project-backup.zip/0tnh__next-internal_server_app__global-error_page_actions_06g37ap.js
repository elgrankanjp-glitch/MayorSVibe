module.exports=[25063,(a,b,c)=>{}];

//# sourceMappingURL=0tnh__next-internal_server_app__global-error_page_actions_06g37ap.js.map