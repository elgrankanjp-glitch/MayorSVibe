module.exports=[89567,(a,b,c)=>{}];

//# sourceMappingURL=0amv_ThevibeSound%20records__next-internal_server_app__not-found_page_actions_0_o09j8.js.map