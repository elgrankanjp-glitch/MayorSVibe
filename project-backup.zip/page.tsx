﻿import React from 'react';

export default function HomePage() {
  return (
    <main style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#05060a', color: '#e6eef6', padding: 24 }}>
      <section style={{ maxWidth: 1100, width: '100%', display: 'flex', gap: 40, alignItems: 'center' }}>
        <div style={{ flex: 1 }}>
          <img src='/assets/brand/soundvibe-master.svg' alt='ThevibeSound' style={{ height: 84, marginBottom: 18 }} />
          <h1 style={{ fontSize: 48, margin: '8px 0', lineHeight: 1.02 }}>ThevibeSound records</h1>
          <p style={{ fontSize: 18, color: '#9fb0c8', marginBottom: 20 }}>Música y vibración en cada nota</p>
          <div style={{ display: 'flex', gap: 12 }}>
            <a href="#releases" style={{ padding: '12px 18px', borderRadius: 10, background: '#06B6D4', color: '#021', fontWeight: 700, textDecoration: 'none' }}>Explorar lanzamientos</a>
            <a href="#contact" style={{ padding: '12px 18px', borderRadius: 10, border: '1px solid rgba(255,255,255,0.06)', color: '#cfe8f5', textDecoration: 'none' }}>Contacto</a>
          </div>
        </div>

        <div style={{ width: 420, height: 300, borderRadius: 16, background: 'linear-gradient(135deg,#0b0b0d 0%, #0f1724 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 10px 30px rgba(2,6,23,0.6)' }}>
          <div style={{ color: '#9fb0c8', textAlign: 'center', padding: 20 }}>
            <div style={{ fontSize: 72, fontWeight: 800 }}>♪</div>
            <div style={{ fontSize: 18 }}>Vibración sonora</div>
          </div>
        </div>
      </section>
    </main>
  );
}
