module.exports=[5903,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_ThevibeSound%20records__next-internal_server_app_page_actions_0_wxrdd.js.map