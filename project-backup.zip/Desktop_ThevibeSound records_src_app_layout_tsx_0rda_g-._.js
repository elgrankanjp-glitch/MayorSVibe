module.exports=[80013,a=>{"use strict";a.i(7997);let b=Error("Cannot find module './globals.css'");throw b.code="MODULE_NOT_FOUND",b},372,a=>{a.n(a.i(80013))}];

//# sourceMappingURL=Desktop_ThevibeSound%20records_src_app_layout_tsx_0rda_g-._.js.map