﻿export const siteConfig = {
  name: 'ThevibeSound records',
  description: 'Música y vibración en cada nota',
  url: 'https://thevibesound.example', // actualiza cuando tengas dominio
  social: {
    twitter: '@thevibesound'
  }
};
